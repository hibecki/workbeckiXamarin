﻿using System;
using MyShop;
using Xamarin.Forms;

namespace MyShopAdmin
{
    public class StoreViewModel : ViewModelBase
	{
		public StoreViewModel  (Page page) : base (page)
		{
		}
	}
}

