﻿using System;
using System.Threading.Tasks;

namespace Acquaint.Abstractions
{
	public interface IDataSyncConflictMessagePresenter
	{
		void PresentConflictMessage();
	}
}

